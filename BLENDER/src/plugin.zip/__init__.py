bl_info = {
    "name": "Metal Material Plugin",
    "author": "Sarka Prokopova",
    "description": "Shows a panel only when an object is selected; adds/assigns a metal material and exposes parameters.",
    "blender": (4, 0, 0),
    "version": (1, 0, 0),
    "location": "View3D > Sidebar > Metal Shader",
    "category": "Material",
}

import bpy
from bpy.props import FloatProperty, FloatVectorProperty, PointerProperty, BoolProperty


def ensure_metal_material(name="Metal"):
    """Create or reuse a Principled BSDF material named `name`."""
    mat = bpy.data.materials.get(name)
    if mat is None:
        mat = bpy.data.materials.new(name=name)

    mat.use_nodes = True
    nodes = mat.node_tree.nodes
    links = mat.node_tree.links

    output = nodes.get("Material Output")
    if output is None:
        output = nodes.new(type="ShaderNodeOutputMaterial")
        output.location = (300, 0)

    bsdf = nodes.get("Principled BSDF")
    if bsdf is None:
        bsdf = nodes.new("ShaderNodeBsdfPrincipled")

    if not bsdf.outputs["BSDF"].is_linked:
        links.new(bsdf.outputs["BSDF"], output.inputs["Surface"])

    # defaults for metal
    bsdf.inputs["Metallic"].default_value = 1.0
    bsdf.inputs["Roughness"].default_value = 0.25

    return mat


def get_or_add_material_slot(obj, mat):
    """Assign mat to obj, if exists -> replace, else add"""
    if obj.material_slots:
        obj.active_material = mat
    else:
        obj.data.materials.append(mat)
        obj.active_material_index = 0
        obj.active_material = mat


def update_metal_settings(self, context):
    """Whenever settings change, push them into the Metal material (if present)."""
    mat = bpy.data.materials.get("Metal")
    if not mat or not mat.use_nodes:
        return
    bsdf = mat.node_tree.nodes.get("Principled BSDF")
    if not bsdf:
        return

    s = context.scene.click_metal_settings
    bsdf.inputs["Base Color"].default_value = (*s.base_color, 1.0)
    bsdf.inputs["Metallic"].default_value = s.metallic
    bsdf.inputs["Roughness"].default_value = s.roughness


class ClickMetalSettings(bpy.types.PropertyGroup):
    base_color: FloatVectorProperty(
        name="Base Color",
        subtype="COLOR",
        min=0.0, max=1.0,
        default=(0.8, 0.8, 0.8),
        update=update_metal_settings,
    )
    metallic: FloatProperty(
        name="Metallic",
        min=0.0, max=1.0,
        default=1.0,
        update=update_metal_settings,
    )
    roughness: FloatProperty(
        name="Roughness",
        min=0.0, max=1.0,
        default=0.25,
        update=update_metal_settings,
    )
    enable_smooth: BoolProperty(
        name = "Smooth",
        default = False
    )


class apply_metal_material(bpy.types.Operator):
    """Append/assign a 'Metal' material to the selected object(s)."""
    bl_idname = "object.apply_metal_material"
    bl_label = "Apply Metal Material"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return (
            context.mode == "OBJECT"
            and context.selected_objects
            and context.active_object is not None
        )

    def execute(self, context):
        mat = ensure_metal_material("Metal")

        # Apply current UI settings to the material
        update_metal_settings(None, context)

        # Assign to all selected relevant objects
        for obj in context.selected_objects:
            if obj.type in {"MESH", "CURVE", "SURFACE", "META", "FONT"} and hasattr(obj.data, "materials"):
                get_or_add_material_slot(obj, mat)
            
            if obj.type == "MESH":
                # If smooth enabled, for better results counting number of edges
                if context.scene.click_metal_settings.enable_smooth:
                    if len(obj.data.edges) <= 48:
                        bpy.ops.object.shade_auto_smooth()
                    else:
                        bpy.ops.object.shade_smooth()
                else:
                    bpy.ops.object.shade_flat()

        return {"FINISHED"}


class VIEW3D_click_metal(bpy.types.Panel):
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "Metal Shader"
    bl_label = "Metal Shader"

    @classmethod
    def poll(cls, context):
        # Only show when an object is selected/active
        return context.mode == "OBJECT" and context.active_object is not None

    def draw(self, context):
        layout = self.layout
        obj = context.active_object

        layout.label(text=f"Active: {obj.name}")

        layout.operator("object.apply_metal_material", icon="MATERIAL")

        layout.separator()
        s = context.scene.click_metal_settings
        layout.prop(s, "base_color")
        layout.prop(s, "metallic")
        layout.prop(s, "roughness")
        layout.prop(s, "enable_smooth")


classes = (
    ClickMetalSettings,
    apply_metal_material,
    VIEW3D_click_metal,
)

def register():
    for cls in classes:
        bpy.utils.register_class(cls)

    bpy.types.Scene.click_metal_settings = PointerProperty(type=ClickMetalSettings)


def unregister():
    del bpy.types.Scene.click_metal_settings

    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)
